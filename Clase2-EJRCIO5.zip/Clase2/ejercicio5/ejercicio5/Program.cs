﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio5
{
    class Program
    {
        static void Main(string[] args)
        {

            int anio;
            int aux;
            bool resp;
            bool flag = false;
            string input;

            Console.WriteLine("ingrese año a determinar: ");
            resp = int.TryParse( Console.ReadLine()  , out aux);
            if(resp)
            {
                if((aux%4)==0)
                {
                    flag = true;
                    if( (aux%100)==0 && (aux%400)==0)
                    {
                        flag = true;
                        
                    }
                    if((aux%100)==0 && (aux%400)!=0)
                    {
                        flag = false;
                    }
                   // if((aux%))

                }
                
            }
            else
            {
                Console.WriteLine("ingrese correctamente");

            }
            
            if(flag)
            {
                Console.WriteLine(aux + " es año bisiesto!");
            }
            else
            {
                Console.WriteLine(aux+" no es bisiesto");
            }



            Console.ReadKey();
        }

    }
}
