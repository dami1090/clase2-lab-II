﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dami1
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            int  acumulador, j, s;
            string divisores = " ";


            for ( i = 1; i <= 9999; i++)
            {
                acumulador = 0;
                s = i / 2;

                for (j = 1; j <= s; j++)
                {

                    if ((i%j) == 0)

                    {
                        if(j==1)
                        {
                            acumulador = acumulador + j;
                            divisores += "" + j + "";
                        }
                        else
                        {
                            acumulador = acumulador + j;
                            divisores += "," + j + "";

                        }
                    }     
                }
                if (acumulador == i)
                    Console.WriteLine("El numero " + i + " es perfecto y su divisores son: " + divisores+".");
                divisores = "";
            }
            Console.ReadKey();









            /* int num,contador=0,numPerf=0,aux=0;
             int cantDigit,suma=0;
             bool perfecto = false;
             do
             {
                 contador++;


                 if( (aux % contador) == 0 && perfecto==false)
                 {

                     suma =suma+ contador;
                     aux = contador;
                     if((suma-contador)==0)
                     {
                         numPerf++;
                         Console.WriteLine(numPerf + ") NUMERO PERFECTO: " + suma);

                     }

                 }




                 Console.WriteLine(contador+") NUMERO PERFECTO: " + num);
             } while (numPerf < 4);*/
            
        }
    }
}
