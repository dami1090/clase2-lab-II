﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary3
{
    class Program
    {
        static void Main(string[] args)
        {
            int valor;

            int max1 = int.MinValue;
            int min1 = int.MaxValue;
            //int i;
            int contador = 0;
            int suma = 0;
            int min = -100;
            int max = 100;
            float prom = 0;
            bool esNum, flag;
            // int cant = 0;
            do
            {
                /*for (i = 0; i < 10; i++)
                {*/

                Console.WriteLine("ingrese un numero: ");
                esNum = int.TryParse(Console.ReadLine(), out valor);
                if (esNum == true)
                {
                    flag = Validacion.Validar(valor, min, max);
                    if (flag == true)
                    {
                        suma = suma + valor;
                        contador++;
                        /* if (i == 0)
                         {
                             max1 = valor;
                             min1 = valor;
                         }
                         else*/
                        if (valor > max1)
                        {
                            max1 = valor;
                        }
                        else if (valor < min1)
                        {
                            min1 = valor;
                        }

                    }
                }
                else
                {
                    Console.WriteLine("ingrese solo numeros:");
                }

            } while (contador < 10);
                prom = (float)suma / contador;
                Console.WriteLine("el promedio es: " + prom);
                Console.WriteLine("el maximo es: " + max1);
                Console.WriteLine("el minimo es: " + min1);

                Console.ReadKey();
        }
    }
}
