﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary3
{
    public class Validacion
    {
        public static int num;

        public static bool Validar(int num, int min, int max)
        {
            bool rango;
            
             if(num < min || num > max)
            {
                rango = false;
                Console.WriteLine("reingrese el numero, sobrepasa los limites");
            }
             else
            {
                rango = true;
            }
            return rango;
        }
    }
}
