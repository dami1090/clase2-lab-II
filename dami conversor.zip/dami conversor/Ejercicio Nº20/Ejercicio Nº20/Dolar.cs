using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes 
{
   class Dolar
  {
    private double cantidad;
        private float precio;
    private static float ContizResPectDolar  =(float)1;

        private Dolar()
        {

        }

        public Dolar(double cant)
        {
            this.cantidad = cant;

        }

        public Dolar(double cant, float cot)
        {
            this.cantidad = cant;
            ContizResPectDolar = cot;


        }



        public double GetCantidad()
        {
            return this.cantidad;
        }

        public float GetCotizacion()
        {
            return ContizResPectDolar;
        }
        

    }

}
