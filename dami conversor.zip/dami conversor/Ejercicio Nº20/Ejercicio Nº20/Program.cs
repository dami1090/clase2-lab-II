using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Billetes;

namespace Ejercicio_Nº20
{
  class Program
  {
    static void Main(string[] args)
    {
            double cantidad;
            double cantidadP;
            double cantidadD;
            bool validar;

            Peso peso = new Peso(17.55);
          
            Peso Peso2 = new Peso(0);
            Dolar dolar = new Dolar(1);
            Euro euro = new Euro(5);

            //dolar.cantidad = 1;
            //euro.cantidad = 5;
            cantidadD = dolar.GetCantidad();
            cantidadP = peso.GetCantidad();


            Console.WriteLine("Peso es:{0} \tDolar es: {1}", cantidadP,cantidadD);
       

            if (peso == dolar)
            {
                Console.WriteLine("Son iguales");
            }
            else
            {
                Console.WriteLine("No son iguales");
            }
            cantidad = Peso2.GetCantidad();

            //Console.WriteLine("La suma es:{0}",cantidad);


            
             Console.ReadKey();

           

             
          

            


    }
  }
}
