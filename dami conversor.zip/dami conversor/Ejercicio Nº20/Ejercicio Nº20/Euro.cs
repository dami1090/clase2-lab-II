using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
   class Euro
  {
    private double cantidad;
    private static float ContizResPectDolar = (float)1.3642;


        public float GetCotizacion()
        {
            return ContizResPectDolar;
        }

        public double GetCantidad()
        {
            return this.cantidad;
        }

        private Euro()
        {

        }

        public Euro(double cant)
        {
            this.cantidad = cant;
        }

        public Euro(double cant, float cot)
        {
            this.cantidad = cant;
            ContizResPectDolar = cot;
        }

        public static Euro operator +(Euro euro, Dolar dolar)
        {
            euro.cantidad += (Math.Round(dolar.GetCantidad() * (ContizResPectDolar)));
            return euro;
        }

        public static Euro operator -(Euro euro, Dolar dolar)
        {
            euro.cantidad -= (dolar.GetCantidad() * (ContizResPectDolar));
            return euro;
        }

        public static bool operator ==(Euro euro, Dolar dolar)
        {
            bool retorno;
            if (euro is null || dolar is null)
            {
                retorno = false;
            }
            else
            {
                if (euro.cantidad == Math.Round(((dolar.GetCantidad()) * (ContizResPectDolar))))
                {
                    retorno = true;
                }
                else
                {
                    retorno = false;
                }
            }
            return retorno;

        }
        public static bool operator !=(Euro euro, Dolar dolar)
        {
            return !(euro == dolar);
        }



    }
}
