using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
     class Peso
    {
        private double cantidad;
        private static float ContizResPectDolar = (float)17.55;

        private Peso()
        {

        }

        public Peso(double cant)
        {
            this.cantidad = cant;
        }

        public Peso(double cant, float cot)
        {
            this.cantidad = cant;
            ContizResPectDolar = cot;
        }



        public static Peso operator +(Peso peso, Dolar dolar)
        {
            peso.cantidad += (Math.Round( dolar.GetCantidad()  * (ContizResPectDolar)));
            return peso;
        }

        public static Peso operator +(Peso peso, Euro euro)
        {
            peso.cantidad += (Math.Round((euro.GetCantidad() * 1.3642) * (ContizResPectDolar)));
            return peso;
        }
        //******************************************
        public static Peso operator -(Peso peso, Dolar dolar)
        {
            peso.cantidad -= (dolar.GetCantidad() * (ContizResPectDolar));
            return peso;
        }

        public static Peso operator -(Peso peso, Euro euro)
        {
            peso.cantidad -= ((euro.GetCantidad() * 1.3642) * (ContizResPectDolar));
            return peso;
        }

        public static bool operator ==(Peso peso, Euro euro)
        {
            bool retorno;
            if (peso is null || euro is null)
            {
                retorno = false;
            }
            else
            {
                if (peso.GetCantidad() == Math.Round(Math.Round(euro.GetCantidad()* 1.3642) * (ContizResPectDolar)))
                {
                    retorno = true;
                }
                else
                {
                    retorno = false;
                }
            }
            return retorno;

        }
        public static bool operator !=(Peso peso, Euro euro)
        {
            return !(peso == euro);
        }
        //*********************************************************************************
        public static bool operator ==(Peso peso, Dolar dolar)
        {
            bool retorno;
            if (peso is null || dolar is null)
            {
                retorno = false;
            }
            else
            {
                if (peso.cantidad == Math.Round(((dolar.GetCantidad()) * (ContizResPectDolar))))
                {
                    retorno = true;
                }
                else
                {
                    retorno = false;
                }
            }
            return retorno;

        }
        public static bool operator !=(Peso peso, Dolar dolar)
        {
            return !(peso == dolar);
        }

        public static bool operator !=(Peso p1, Peso p2)
        {
            return !(p1 == p2);
        }

        public static bool operator ==(Peso p1, Peso p2)
        {
            bool retorno;
            if (p1 is null || p2 is null)
            {
                retorno = false;
            }
            else
            {
                if (p1 == p2)
                {
                    retorno = true;
                }
                else
                {
                    retorno = false;
                }
            }

            return retorno;
        }

        //*******************************************
        public double GetCantidad()
        {
            return this.cantidad;
        }
        public float GetCotizacion()
        {
            return ContizResPectDolar;
        }

        public static explicit operator Dolar(Peso peso)
        {
            //
            //retorno.cantidad = ;
            Dolar retorno = new Dolar(peso.cantidad * ContizResPectDolar);
            return retorno;
        }

        public static explicit operator Euro(Peso peso)
        {
            Euro retorno = new Euro(peso.cantidad * (ContizResPectDolar * 1.3642));
            return retorno;
        }

        public static implicit operator Peso(double peso)
        {
            Peso p = new Peso();
            p.cantidad = peso;

            return p;
        } 
        
        public static explicit operator Euro (Peso peso)
        {
            double eu = peso.cantidad * (ContizResPectDolar * 1.3642);
            Euro retorno = new Euro(eu);
            return retorno;


        }


    }
}
